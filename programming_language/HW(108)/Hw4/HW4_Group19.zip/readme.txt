Compile : gcc -g -Wall -fopenmp -o pl_hw4 pl_hw4.c
Execute : ./pl_hw4 8 test3 output.txt
