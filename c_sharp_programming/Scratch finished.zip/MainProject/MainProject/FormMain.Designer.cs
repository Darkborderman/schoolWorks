﻿namespace MainProject
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LabelScore = new System.Windows.Forms.Label();
            this.TimerSync = new System.Windows.Forms.Timer(this.components);
            this.LabelEnglish = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LabelScore
            // 
            this.LabelScore.AutoSize = true;
            this.LabelScore.Location = new System.Drawing.Point(457, 364);
            this.LabelScore.Name = "LabelScore";
            this.LabelScore.Size = new System.Drawing.Size(49, 17);
            this.LabelScore.TabIndex = 1;
            this.LabelScore.Text = "Score:";
            // 
            // TimerSync
            // 
            this.TimerSync.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // LabelEnglish
            // 
            this.LabelEnglish.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LabelEnglish.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LabelEnglish.Location = new System.Drawing.Point(663, 89);
            this.LabelEnglish.Name = "LabelEnglish";
            this.LabelEnglish.Size = new System.Drawing.Size(100, 50);
            this.LabelEnglish.TabIndex = 3;
            this.LabelEnglish.Text = "English";
            this.LabelEnglish.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LabelEnglish.Click += new System.EventHandler(this.LabelEnglish_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 503);
            this.Controls.Add(this.LabelEnglish);
            this.Controls.Add(this.LabelScore);
            this.Name = "FormMain";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label LabelScore;
        private System.Windows.Forms.Timer TimerSync;
        private System.Windows.Forms.Label LabelEnglish;
    }
}

