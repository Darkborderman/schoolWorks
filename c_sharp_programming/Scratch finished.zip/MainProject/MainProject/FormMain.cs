﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainProject
{
    //Main Form of the Project
    public partial class FormMain : Form
    {
        //use public and static so that other form can get variables
        public static int score = 0;
        public static String user = "NULL";
        //new each of the form
        FormEnglish FE = new FormEnglish();

        public FormMain()
        {
            InitializeComponent();
            FE.Hide();
            TimerSync.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LabelScore.Text = "Score: " + score;
        }

        private void LabelEnglish_Click(object sender, EventArgs e)
        {
            FE.Show();
        }
    }
}
