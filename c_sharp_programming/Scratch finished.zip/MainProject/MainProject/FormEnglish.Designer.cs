﻿namespace MainProject
{
    partial class FormEnglish
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TimerTicks = new System.Windows.Forms.Timer(this.components);
            this.BoxGround = new System.Windows.Forms.PictureBox();
            this.LabelStart = new System.Windows.Forms.Label();
            this.LabelExit = new System.Windows.Forms.Label();
            this.BoxAlphabet1 = new System.Windows.Forms.Label();
            this.LabelScore = new System.Windows.Forms.Label();
            this.LabelLife = new System.Windows.Forms.Label();
            this.BoxAlphabet3 = new System.Windows.Forms.Label();
            this.BoxAlphabet2 = new System.Windows.Forms.Label();
            this.BoxAlphabet4 = new System.Windows.Forms.Label();
            this.BoxAlphabet8 = new System.Windows.Forms.Label();
            this.BoxAlphabet6 = new System.Windows.Forms.Label();
            this.BoxAlphabet5 = new System.Windows.Forms.Label();
            this.BoxAlphabet7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.BoxGround)).BeginInit();
            this.SuspendLayout();
            // 
            // TimerTicks
            // 
            this.TimerTicks.Tick += new System.EventHandler(this.TimerTicks_Tick);
            // 
            // BoxGround
            // 
            this.BoxGround.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BoxGround.Location = new System.Drawing.Point(12, 441);
            this.BoxGround.Name = "BoxGround";
            this.BoxGround.Size = new System.Drawing.Size(958, 50);
            this.BoxGround.TabIndex = 1;
            this.BoxGround.TabStop = false;
            // 
            // LabelStart
            // 
            this.LabelStart.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LabelStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LabelStart.Location = new System.Drawing.Point(858, 9);
            this.LabelStart.Name = "LabelStart";
            this.LabelStart.Size = new System.Drawing.Size(100, 50);
            this.LabelStart.TabIndex = 2;
            this.LabelStart.Text = "Start";
            this.LabelStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LabelStart.Click += new System.EventHandler(this.LabelStart_Click);
            // 
            // LabelExit
            // 
            this.LabelExit.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LabelExit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LabelExit.Location = new System.Drawing.Point(858, 79);
            this.LabelExit.Name = "LabelExit";
            this.LabelExit.Size = new System.Drawing.Size(100, 50);
            this.LabelExit.TabIndex = 3;
            this.LabelExit.Text = "Exit";
            this.LabelExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LabelExit.Click += new System.EventHandler(this.LabelExit_Click);
            // 
            // BoxAlphabet1
            // 
            this.BoxAlphabet1.BackColor = System.Drawing.SystemColors.Info;
            this.BoxAlphabet1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BoxAlphabet1.Location = new System.Drawing.Point(147, 125);
            this.BoxAlphabet1.Name = "BoxAlphabet1";
            this.BoxAlphabet1.Size = new System.Drawing.Size(40, 40);
            this.BoxAlphabet1.TabIndex = 4;
            this.BoxAlphabet1.Text = "A";
            this.BoxAlphabet1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LabelScore
            // 
            this.LabelScore.AutoSize = true;
            this.LabelScore.Location = new System.Drawing.Point(9, 26);
            this.LabelScore.Name = "LabelScore";
            this.LabelScore.Size = new System.Drawing.Size(49, 17);
            this.LabelScore.TabIndex = 5;
            this.LabelScore.Text = "Score:";
            // 
            // LabelLife
            // 
            this.LabelLife.AutoSize = true;
            this.LabelLife.Location = new System.Drawing.Point(9, 96);
            this.LabelLife.Name = "LabelLife";
            this.LabelLife.Size = new System.Drawing.Size(39, 17);
            this.LabelLife.TabIndex = 6;
            this.LabelLife.Text = "Life: ";
            // 
            // BoxAlphabet3
            // 
            this.BoxAlphabet3.BackColor = System.Drawing.SystemColors.Info;
            this.BoxAlphabet3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BoxAlphabet3.Location = new System.Drawing.Point(313, 26);
            this.BoxAlphabet3.Name = "BoxAlphabet3";
            this.BoxAlphabet3.Size = new System.Drawing.Size(40, 40);
            this.BoxAlphabet3.TabIndex = 7;
            this.BoxAlphabet3.Text = "C";
            this.BoxAlphabet3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BoxAlphabet2
            // 
            this.BoxAlphabet2.BackColor = System.Drawing.SystemColors.Info;
            this.BoxAlphabet2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BoxAlphabet2.Location = new System.Drawing.Point(233, 197);
            this.BoxAlphabet2.Name = "BoxAlphabet2";
            this.BoxAlphabet2.Size = new System.Drawing.Size(40, 40);
            this.BoxAlphabet2.TabIndex = 8;
            this.BoxAlphabet2.Text = "B";
            this.BoxAlphabet2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BoxAlphabet4
            // 
            this.BoxAlphabet4.BackColor = System.Drawing.SystemColors.Info;
            this.BoxAlphabet4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BoxAlphabet4.Location = new System.Drawing.Point(397, 79);
            this.BoxAlphabet4.Name = "BoxAlphabet4";
            this.BoxAlphabet4.Size = new System.Drawing.Size(40, 40);
            this.BoxAlphabet4.TabIndex = 9;
            this.BoxAlphabet4.Text = "D";
            this.BoxAlphabet4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BoxAlphabet8
            // 
            this.BoxAlphabet8.BackColor = System.Drawing.SystemColors.Info;
            this.BoxAlphabet8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BoxAlphabet8.Location = new System.Drawing.Point(640, 59);
            this.BoxAlphabet8.Name = "BoxAlphabet8";
            this.BoxAlphabet8.Size = new System.Drawing.Size(40, 40);
            this.BoxAlphabet8.TabIndex = 10;
            this.BoxAlphabet8.Text = "H";
            this.BoxAlphabet8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BoxAlphabet6
            // 
            this.BoxAlphabet6.BackColor = System.Drawing.SystemColors.Info;
            this.BoxAlphabet6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BoxAlphabet6.Location = new System.Drawing.Point(548, 26);
            this.BoxAlphabet6.Name = "BoxAlphabet6";
            this.BoxAlphabet6.Size = new System.Drawing.Size(40, 40);
            this.BoxAlphabet6.TabIndex = 11;
            this.BoxAlphabet6.Text = "F";
            this.BoxAlphabet6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BoxAlphabet5
            // 
            this.BoxAlphabet5.BackColor = System.Drawing.SystemColors.Info;
            this.BoxAlphabet5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BoxAlphabet5.Location = new System.Drawing.Point(474, 152);
            this.BoxAlphabet5.Name = "BoxAlphabet5";
            this.BoxAlphabet5.Size = new System.Drawing.Size(40, 40);
            this.BoxAlphabet5.TabIndex = 12;
            this.BoxAlphabet5.Text = "E";
            this.BoxAlphabet5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BoxAlphabet7
            // 
            this.BoxAlphabet7.BackColor = System.Drawing.SystemColors.Info;
            this.BoxAlphabet7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BoxAlphabet7.Location = new System.Drawing.Point(576, 96);
            this.BoxAlphabet7.Name = "BoxAlphabet7";
            this.BoxAlphabet7.Size = new System.Drawing.Size(40, 40);
            this.BoxAlphabet7.TabIndex = 13;
            this.BoxAlphabet7.Text = "G";
            this.BoxAlphabet7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormEnglish
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 503);
            this.Controls.Add(this.BoxAlphabet7);
            this.Controls.Add(this.BoxAlphabet5);
            this.Controls.Add(this.BoxAlphabet6);
            this.Controls.Add(this.BoxAlphabet8);
            this.Controls.Add(this.BoxAlphabet4);
            this.Controls.Add(this.BoxAlphabet2);
            this.Controls.Add(this.BoxAlphabet3);
            this.Controls.Add(this.LabelLife);
            this.Controls.Add(this.LabelScore);
            this.Controls.Add(this.BoxAlphabet1);
            this.Controls.Add(this.LabelExit);
            this.Controls.Add(this.LabelStart);
            this.Controls.Add(this.BoxGround);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormEnglish";
            this.Text = "FormEnglish";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormEnglish_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.BoxGround)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer TimerTicks;
        private System.Windows.Forms.PictureBox BoxGround;
        private System.Windows.Forms.Label LabelStart;
        private System.Windows.Forms.Label LabelExit;
        private System.Windows.Forms.Label BoxAlphabet1;
        private System.Windows.Forms.Label LabelScore;
        private System.Windows.Forms.Label LabelLife;
        private System.Windows.Forms.Label BoxAlphabet3;
        private System.Windows.Forms.Label BoxAlphabet2;
        private System.Windows.Forms.Label BoxAlphabet4;
        private System.Windows.Forms.Label BoxAlphabet8;
        private System.Windows.Forms.Label BoxAlphabet6;
        private System.Windows.Forms.Label BoxAlphabet5;
        private System.Windows.Forms.Label BoxAlphabet7;
    }
}