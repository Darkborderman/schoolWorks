﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainProject
{
    //English Form
    public partial class FormEnglish : Form
    {
        int score = 0;
        int life = 3;

        public FormEnglish()
        {
            InitializeComponent();
            BoxAlphabet1.Visible = false;
            BoxAlphabet2.Visible = false;
            BoxAlphabet3.Visible = false;
            BoxAlphabet4.Visible = false;
            BoxAlphabet5.Visible = false;
            BoxAlphabet6.Visible = false;
            BoxAlphabet7.Visible = false;
            BoxAlphabet8.Visible = false;
        }

        private void LabelStart_Click(object sender, EventArgs e)
        {
            TimerTicks.Start();
            BoxAlphabet1.Visible = true;
            BoxAlphabet2.Visible = true;
            BoxAlphabet3.Visible = true;
            BoxAlphabet4.Visible = true;
            BoxAlphabet5.Visible = true;
            BoxAlphabet6.Visible = true;
            BoxAlphabet7.Visible = true;
            BoxAlphabet8.Visible = true;
        }

        //Store score and init when exit
        private void LabelExit_Click(object sender, EventArgs e)
        {
            FormMain.score += this.score;
            life = 3;
            score = 0;
            TimerTicks.Stop();
            this.Hide();
        }
        private void TimerTicks_Tick(object sender, EventArgs e)
        {
            updateScreen();
            detect();
        }

        private void FormEnglish_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData.ToString() == BoxAlphabet1.Text.ToString()) { BoxAlphabet1 = reset(BoxAlphabet1); score++; }
            if (e.KeyData.ToString() == BoxAlphabet2.Text.ToString()) { BoxAlphabet2 = reset(BoxAlphabet2); score++; }
            if (e.KeyData.ToString() == BoxAlphabet3.Text.ToString()) { BoxAlphabet3 = reset(BoxAlphabet3); score++; }
            if (e.KeyData.ToString() == BoxAlphabet4.Text.ToString()) { BoxAlphabet4 = reset(BoxAlphabet4); score++; }
            if (e.KeyData.ToString() == BoxAlphabet5.Text.ToString()) { BoxAlphabet5 = reset(BoxAlphabet5); score++; }
            if (e.KeyData.ToString() == BoxAlphabet6.Text.ToString()) { BoxAlphabet6 = reset(BoxAlphabet6); score++; }
            if (e.KeyData.ToString() == BoxAlphabet7.Text.ToString()) { BoxAlphabet7 = reset(BoxAlphabet7); score++; }
            if (e.KeyData.ToString() == BoxAlphabet8.Text.ToString()) { BoxAlphabet8 = reset(BoxAlphabet8); score++; }
        }
        private Label reset(Label x)
        {
            Random rnd = new Random();
            x.Location = new Point(rnd.Next(100, 600), rnd.Next(100, 100));
            int xxx;
            xxx = rnd.Next(1, 27);
            if (xxx == 1) x.Text = "A";
            if (xxx == 2) x.Text = "B";
            if (xxx == 3) x.Text = "C";
            if (xxx == 4) x.Text = "D";
            if (xxx == 5) x.Text = "E";
            if (xxx == 6) x.Text = "F";
            if (xxx == 7) x.Text = "G";
            if (xxx == 8) x.Text = "H";
            if (xxx == 9) x.Text = "I";
            if (xxx == 10) x.Text = "J";
            if (xxx == 11) x.Text = "K";
            if (xxx == 12) x.Text = "L";
            if (xxx == 13) x.Text = "M";
            if (xxx == 14) x.Text = "N";
            if (xxx == 15) x.Text = "O";
            if (xxx == 16) x.Text = "P";
            if (xxx == 17) x.Text = "Q";
            if (xxx == 18) x.Text = "R";
            if (xxx == 19) x.Text = "S";
            if (xxx == 20) x.Text = "T";
            if (xxx == 21) x.Text = "U";
            if (xxx == 22) x.Text = "V";
            if (xxx == 23) x.Text = "W";
            if (xxx == 24) x.Text = "X";
            if (xxx == 25) x.Text = "Y";
            if (xxx == 26) x.Text = "Z";
            return x;
        }
        private void updateScreen()
        {
            BoxAlphabet1.Location = new Point(BoxAlphabet1.Location.X, BoxAlphabet1.Location.Y + 3);
            BoxAlphabet2.Location = new Point(BoxAlphabet2.Location.X, BoxAlphabet2.Location.Y + 3);
            BoxAlphabet3.Location = new Point(BoxAlphabet3.Location.X, BoxAlphabet3.Location.Y + 3);
            BoxAlphabet4.Location = new Point(BoxAlphabet4.Location.X, BoxAlphabet4.Location.Y + 3);
            BoxAlphabet5.Location = new Point(BoxAlphabet5.Location.X, BoxAlphabet5.Location.Y + 3);
            BoxAlphabet6.Location = new Point(BoxAlphabet6.Location.X, BoxAlphabet6.Location.Y + 3);
            BoxAlphabet7.Location = new Point(BoxAlphabet7.Location.X, BoxAlphabet7.Location.Y + 3);
            BoxAlphabet8.Location = new Point(BoxAlphabet8.Location.X, BoxAlphabet8.Location.Y + 3);
            LabelScore.Text = "Score: " + score;
            LabelLife.Text = "Life: " + life;
            if (life < 1) TimerTicks.Stop();
        }
        private void detect()
        {
            if (BoxAlphabet1.Bounds.IntersectsWith(BoxGround.Bounds))
            { life--; BoxAlphabet1 = reset(BoxAlphabet1); }
            if (BoxAlphabet2.Bounds.IntersectsWith(BoxGround.Bounds))
            { life--; BoxAlphabet2 = reset(BoxAlphabet2); }
            if (BoxAlphabet3.Bounds.IntersectsWith(BoxGround.Bounds))
            { life--; BoxAlphabet3 = reset(BoxAlphabet3); }
            if (BoxAlphabet4.Bounds.IntersectsWith(BoxGround.Bounds))
            { life--; BoxAlphabet4 = reset(BoxAlphabet4); }
            if (BoxAlphabet5.Bounds.IntersectsWith(BoxGround.Bounds))
            { life--; BoxAlphabet5 = reset(BoxAlphabet5); }
            if (BoxAlphabet6.Bounds.IntersectsWith(BoxGround.Bounds))
            { life--; BoxAlphabet6 = reset(BoxAlphabet6); }
            if (BoxAlphabet7.Bounds.IntersectsWith(BoxGround.Bounds))
            { life--; BoxAlphabet7 = reset(BoxAlphabet7); }
            if (BoxAlphabet8.Bounds.IntersectsWith(BoxGround.Bounds))
            { life--; BoxAlphabet8 = reset(BoxAlphabet8); }
        }
    }
}
