﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool flag = false;
            int selection;
            int size = 0;
            student[] table=new student[0];
            while (true)
            {
                Console.WriteLine("Choose operation 1)input 2)print 3)sort 0)exit");
                selection = int.Parse(Console.ReadLine());
                Console.WriteLine("{0}",selection);
                if (selection == 0)
                {
                    Console.WriteLine("Bye");
                    break;
                }
                else if (selection == 1)
                {
                    flag = true;
                    Console.WriteLine("Input class number");
                    size = int.Parse(Console.ReadLine());
                    table = new student[size];
                    for(int i=0;i<=size-1;i++)
                    {
                        table[i].id = i + 1;
                        Console.WriteLine("Input {0} student grade", i+1);
                        Console.WriteLine("Input Chinese Grade");
                        table[i].chinese = int.Parse(Console.ReadLine());
                        Console.WriteLine("Input English Grade");
                        table[i].english = int.Parse(Console.ReadLine());
                        Console.WriteLine("Input Math Grade");
                        table[i].math = int.Parse(Console.ReadLine());
                    }
                    
                }
                else if (selection == 2)
                {
                    if (flag == false) Console.WriteLine("No data");
                    else
                    {
                        for(int i=0;i<=size-1;i++)
                        {
                            Console.WriteLine("ID | Chinese | English | Math");
                            Console.WriteLine("{0}  | {1}      | {2}      |   {3}", table[i].id, table[i].chinese, table[i].english, table[i].math);
                        }
                    }
                    
                }
                else if(selection == 3)
                {
                    if (flag == false) Console.WriteLine("No data");
                    else
                    {
                        Console.WriteLine("Sort by 1)id 2)chinese 3)english 4)math");
                        int choose = int.Parse(Console.ReadLine());
                        if (choose == 1) Array.Sort<student>(table, (x, y) => x.id.CompareTo(y.id));
                        else if (choose == 2) Array.Sort<student>(table, (x, y) => x.chinese.CompareTo(y.chinese));
                        else if (choose == 3) Array.Sort<student>(table, (x, y) => x.english.CompareTo(y.english));
                        else if (choose == 4) Array.Sort<student>(table, (x, y) => x.math.CompareTo(y.math));
                        else Console.WriteLine("Invaild operation!");
                    }
                }
                else Console.WriteLine("Invaild operation!");
            }
            Console.Read();
        }
        
    }
    struct student
    {
        public
        int chinese, math, english,id;
    }
}