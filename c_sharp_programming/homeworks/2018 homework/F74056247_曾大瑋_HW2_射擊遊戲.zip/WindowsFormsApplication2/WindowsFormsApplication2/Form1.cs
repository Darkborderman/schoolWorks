﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace WindowsFormsApplication2
{
    public partial class PlaneShooter : Form
    {
        bool gameStart = false;
        public PlaneShooter()
        {
            InitializeComponent();
            gameReset();
        }
        public void PlaneShooter_KeyDown(object sender, KeyEventArgs e)
        {
            int key = e.KeyValue;
            //move plane 
            int X = gamePlayer.Location.X;
            int Y = gamePlayer.Location.Y;
            if (gameStart&&gameStartButton.Visible==false)
            {
                if ((key == 37 || key == 65) && X >= 440) gamePlayer.Location = new Point(X - 10, Y);
                if ((key == 39 || key == 68) && X <= 700) gamePlayer.Location = new Point(X + 10, Y);
                //shoot bullet
                if (key == 32)
                {
                    SoundPlayer shoot = new SoundPlayer(@"..\..\assets\sfxs\friend_shoot.wav");
                    shoot.Play();
                    playerShoot();
                }

                //change game speed(or so called difficulty)
                if (key == 49) setTimeInterval(500);
                if (key == 50) setTimeInterval(100);
                if (key == 51) setTimeInterval(20);
            }

            //Reset the game
            if (key == 82) gameReset();
        }
        public void playerShoot()
        {
            Point playerLocation = gamePlayer.Location;
            if (gamePlayerBullet1.Visible == false)
            {
                gamePlayerBullet1.Visible= true;
                gamePlayerBullet1.Location = new Point(playerLocation.X, playerLocation.Y - 40);
            }
            else if (gamePlayerBullet2.Visible == false)
            {
                gamePlayerBullet2.Visible = true;
                gamePlayerBullet2.Location = new Point(playerLocation.X, playerLocation.Y - 40);
            }
            else if (gamePlayerBullet3.Visible == false)
            {
                gamePlayerBullet3.Visible = true;
                gamePlayerBullet3.Location = new Point(playerLocation.X, playerLocation.Y - 40);
            }
        }
        public void gameTime_Tick(object sender, EventArgs e)
        {
            if (gameStartButton.Visible == false)
            {
                bulletMove();
                enemyMove();
                playerInteract();
                enemyInteract();
            }
        }
        public void bulletMove()
        {
            Point bullet1Location = gamePlayerBullet1.Location;
            gamePlayerBullet1.Location = new Point(bullet1Location.X, bullet1Location.Y - 10);
            if (bullet1Location.Y <= 240) gamePlayerBullet1.Visible = false;

            Point bullet2Location = gamePlayerBullet2.Location;
            gamePlayerBullet2.Location = new Point(bullet2Location.X, bullet2Location.Y - 10);
            if (bullet2Location.Y <= 240) gamePlayerBullet2.Visible = false;

            Point bullet3Location = gamePlayerBullet3.Location;
            gamePlayerBullet3.Location = new Point(bullet3Location.X, bullet3Location.Y - 10);
            if (bullet3Location.Y <= 240) gamePlayerBullet3.Visible = false;
        }
        public void enemyMove()
        {
            Point enemy1Location = gameEnemy1.Location;
            gameEnemy1.Location = new Point(enemy1Location.X, enemy1Location.Y + 10);
            if (enemy1Location.Y >= 570) gameEnemy1.Location = new Point(enemy1Location.X, enemy1Location.Y - 350);
            Point enemy2Location = gameEnemy2.Location;
            gameEnemy2.Location = new Point(enemy2Location.X, enemy2Location.Y + 10);
            if (enemy2Location.Y >= 570) gameEnemy2.Location = new Point(enemy2Location.X, enemy2Location.Y - 350);
        }
        public void playerInteract()
        {
            if (gamePlayer.Bounds.IntersectsWith(gameEnemy1.Bounds)) playerDamaged();
            else if(gamePlayer.Bounds.IntersectsWith(gameEnemy2.Bounds)) playerDamaged();
        }
        public void playerDamaged()
        {
            SoundPlayer damaged = new SoundPlayer(@"..\..\assets\sfxs\friend_dead.wav");
            damaged.Play();
            if (gameLife1.Visible == true)
            {
                gameLife1.Visible = false;
                gamePlayer.Location = new Point(430, 580);
            }
            else if(gameLife1.Visible == false)
            {
                gameLose();
            }
        }
        public void enemyInteract()
        {
            //
            if (gameEnemy1.Bounds.IntersectsWith(gamePlayerBullet1.Bounds))
            {
                gameEnemy1.Location = new Point(480, 220);
                gamePlayerBullet1.Location = new Point(0, 0);
                gamePlayerBullet1.Visible = false;
                enemyDamaged();
            }
            if (gameEnemy1.Bounds.IntersectsWith(gamePlayerBullet2.Bounds))
            {
                gameEnemy1.Location = new Point(480, 220);
                gamePlayerBullet2.Location = new Point(0, 0);
                gamePlayerBullet2.Visible = false;
                enemyDamaged();
            }
            if (gameEnemy1.Bounds.IntersectsWith(gamePlayerBullet3.Bounds))
            {
                gameEnemy1.Location = new Point(480, 220);
                gamePlayerBullet3.Location = new Point(0, 0);
                gamePlayerBullet3.Visible = false;
                enemyDamaged();
            }
            //
            if (gameEnemy2.Bounds.IntersectsWith(gamePlayerBullet1.Bounds))
            {
                gameEnemy2.Location = new Point(600, 300);
                gamePlayerBullet1.Location = new Point(0, 0);
                gamePlayerBullet1.Visible = false;
                enemyDamaged();
            }
            if (gameEnemy2.Bounds.IntersectsWith(gamePlayerBullet2.Bounds))
            {
                gameEnemy2.Location = new Point(600, 300);
                gamePlayerBullet2.Location = new Point(0, 0);
                gamePlayerBullet2.Visible = false;
                enemyDamaged();
            }
            if (gameEnemy2.Bounds.IntersectsWith(gamePlayerBullet3.Bounds))
            {
                gameEnemy2.Location = new Point(600, 300);
                gamePlayerBullet3.Location = new Point(0, 0);
                gamePlayerBullet3.Visible = false;
                enemyDamaged();
            }
            //
        }
        public void enemyDamaged()
        {
            SoundPlayer damaged = new SoundPlayer(@"..\..\assets\sfxs\enemy_dead.wav");
            damaged.Play();
            if (gameRemain3.Visible == true)
            {
                gameRemain3.Visible = false;
            }
            else if (gameRemain2.Visible == true)
            {
                gameRemain2.Visible = false;
            }
            else if (gameRemain1.Visible == true)
            {
                gameRemain1.Visible = false;
            }
            else if (gameRemain1.Visible == false)
            {
                gameWin();
            }
        }
        public void initGameFramework()
        {
            gameFrame.SizeMode = PictureBoxSizeMode.StretchImage;
            gameFrame.Image = Image.FromFile(@"..\..\assets\images\frame.png");
            gameBackground.SizeMode = PictureBoxSizeMode.StretchImage;
            gameBackground.Image = Image.FromFile(@"..\..\assets\images\background.png");
            gameScreen.SizeMode = PictureBoxSizeMode.StretchImage;
            gameScreen.Image = Image.FromFile(@"..\..\assets\images\gamescreen.png");
            gameLifeTitle.SizeMode = PictureBoxSizeMode.StretchImage;
            gameLifeTitle.Image = Image.FromFile(@"..\..\assets\images\life.png");
            gameRemainTitle.SizeMode = PictureBoxSizeMode.StretchImage;
            gameRemainTitle.Image = Image.FromFile(@"..\..\assets\images\remain.png");
            gameStartButton.SizeMode = PictureBoxSizeMode.StretchImage;
            gameStartButton.Image = Image.FromFile(@"..\..\assets\images\background.png");
        }
        public void initGameTimer()
        {
            gameTime.Interval = 500;
            gameTime.Start();
        }
        public void initBullet()
        {
            gamePlayerBullet1.SizeMode = PictureBoxSizeMode.StretchImage;
            gamePlayerBullet1.Image = Image.FromFile(@"..\..\assets\images\bullet.png");
            gamePlayerBullet1.Visible = false;
            gamePlayerBullet1.Location = new Point(0, 0);
            gamePlayerBullet2.SizeMode = PictureBoxSizeMode.StretchImage;
            gamePlayerBullet2.Image = Image.FromFile(@"..\..\assets\images\bullet.png");
            gamePlayerBullet2.Visible = false;
            gamePlayerBullet1.Location = new Point(0, 0);
            gamePlayerBullet3.SizeMode = PictureBoxSizeMode.StretchImage;
            gamePlayerBullet3.Image = Image.FromFile(@"..\..\assets\images\bullet.png");
            gamePlayerBullet3.Visible = false;
            gamePlayerBullet1.Location = new Point(0, 0);
        }
        public void initPlayer()
        {
            gamePlayer.SizeMode = PictureBoxSizeMode.StretchImage;
            gamePlayer.Image = Image.FromFile(@"..\..\assets\images\friend.png");
            gamePlayer.Location = new Point(430, 580);
            gamePlayer.Visible = true;
        }
        public void initEnemy()
        {
            gameEnemy1.SizeMode = PictureBoxSizeMode.StretchImage;
            gameEnemy1.Image = Image.FromFile(@"..\..\assets\images\enemy.png");
            gameEnemy1.Visible = true;
            gameEnemy1.Location = new Point(480, 220);
            gameEnemy2.SizeMode = PictureBoxSizeMode.StretchImage;
            gameEnemy2.Image = Image.FromFile(@"..\..\assets\images\enemy.png");
            gameEnemy2.Visible = true;
            gameEnemy2.Location = new Point(600, 300);
        }
        public void initLife()
        {
            gameLife1.SizeMode = PictureBoxSizeMode.StretchImage;
            gameLife1.Image = Image.FromFile(@"..\..\assets\images\friend.png");
            gameLife1.Visible = true;
        }
        public void initRemain()
        {
            gameRemain1.SizeMode = PictureBoxSizeMode.StretchImage;
            gameRemain1.Image = Image.FromFile(@"..\..\assets\images\enemy.png");
            gameRemain1.Visible = true;

            gameRemain2.SizeMode = PictureBoxSizeMode.StretchImage;
            gameRemain2.Image = Image.FromFile(@"..\..\assets\images\enemy.png");
            gameRemain2.Visible = true;

            gameRemain3.SizeMode = PictureBoxSizeMode.StretchImage;
            gameRemain3.Image = Image.FromFile(@"..\..\assets\images\enemy.png");
            gameRemain3.Visible = true;
        }
        public void setTimeInterval(int interval)
        {
            gameTime.Interval = interval;
        }
        public void gameReset()
        {
            gameStart = true;
            initGameFramework();
            initGameTimer();
            initPlayer();
            initBullet();
            initLife();
            initEnemy();
            initRemain();
        }
        public void gameWin()
        {
            gameStart = false;
            gameTime.Stop();
            MessageBox.Show("You win!");
        }
        public void gameLose()
        {
            gameStart = false;
            gameTime.Stop();
            MessageBox.Show("You Lose!");
        }
        public void gameStartButton_Click(object sender, EventArgs e)
        {
            gameStartButton.Visible = false;
            gameReset();
        }
    }
}