﻿namespace WindowsFormsApplication2
{
    partial class PlaneShooter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gameFrame = new System.Windows.Forms.PictureBox();
            this.gameBackground = new System.Windows.Forms.PictureBox();
            this.gameScreen = new System.Windows.Forms.PictureBox();
            this.gameLifeTitle = new System.Windows.Forms.PictureBox();
            this.gameRemainTitle = new System.Windows.Forms.PictureBox();
            this.gamePlayer = new System.Windows.Forms.PictureBox();
            this.gamePlayerBullet1 = new System.Windows.Forms.PictureBox();
            this.gameTime = new System.Windows.Forms.Timer(this.components);
            this.gameLife1 = new System.Windows.Forms.PictureBox();
            this.gamePlayerBullet2 = new System.Windows.Forms.PictureBox();
            this.gamePlayerBullet3 = new System.Windows.Forms.PictureBox();
            this.gameEnemy1 = new System.Windows.Forms.PictureBox();
            this.gameRemain1 = new System.Windows.Forms.PictureBox();
            this.gameEnemy2 = new System.Windows.Forms.PictureBox();
            this.gameRemain2 = new System.Windows.Forms.PictureBox();
            this.gameRemain3 = new System.Windows.Forms.PictureBox();
            this.gameStartButton = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.gameFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameBackground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameScreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameLifeTitle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameRemainTitle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gamePlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gamePlayerBullet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameLife1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gamePlayerBullet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gamePlayerBullet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameEnemy1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameRemain1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameEnemy2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameRemain2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameRemain3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameStartButton)).BeginInit();
            this.SuspendLayout();
            // 
            // gameFrame
            // 
            this.gameFrame.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gameFrame.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gameFrame.Cursor = System.Windows.Forms.Cursors.Default;
            this.gameFrame.Location = new System.Drawing.Point(12, 12);
            this.gameFrame.Name = "gameFrame";
            this.gameFrame.Size = new System.Drawing.Size(1882, 1013);
            this.gameFrame.TabIndex = 0;
            this.gameFrame.TabStop = false;
            // 
            // gameBackground
            // 
            this.gameBackground.BackColor = System.Drawing.SystemColors.ControlDark;
            this.gameBackground.Location = new System.Drawing.Point(524, 268);
            this.gameBackground.Name = "gameBackground";
            this.gameBackground.Size = new System.Drawing.Size(854, 496);
            this.gameBackground.TabIndex = 1;
            this.gameBackground.TabStop = false;
            // 
            // gameScreen
            // 
            this.gameScreen.BackColor = System.Drawing.SystemColors.Highlight;
            this.gameScreen.Location = new System.Drawing.Point(524, 268);
            this.gameScreen.Name = "gameScreen";
            this.gameScreen.Size = new System.Drawing.Size(541, 496);
            this.gameScreen.TabIndex = 2;
            this.gameScreen.TabStop = false;
            // 
            // gameLifeTitle
            // 
            this.gameLifeTitle.BackColor = System.Drawing.SystemColors.HotTrack;
            this.gameLifeTitle.Location = new System.Drawing.Point(1062, 268);
            this.gameLifeTitle.Name = "gameLifeTitle";
            this.gameLifeTitle.Size = new System.Drawing.Size(316, 53);
            this.gameLifeTitle.TabIndex = 3;
            this.gameLifeTitle.TabStop = false;
            // 
            // gameRemainTitle
            // 
            this.gameRemainTitle.BackColor = System.Drawing.SystemColors.HotTrack;
            this.gameRemainTitle.Location = new System.Drawing.Point(1062, 436);
            this.gameRemainTitle.Name = "gameRemainTitle";
            this.gameRemainTitle.Size = new System.Drawing.Size(316, 50);
            this.gameRemainTitle.TabIndex = 4;
            this.gameRemainTitle.TabStop = false;
            // 
            // gamePlayer
            // 
            this.gamePlayer.Location = new System.Drawing.Point(581, 714);
            this.gamePlayer.Name = "gamePlayer";
            this.gamePlayer.Size = new System.Drawing.Size(55, 50);
            this.gamePlayer.TabIndex = 5;
            this.gamePlayer.TabStop = false;
            // 
            // gamePlayerBullet1
            // 
            this.gamePlayerBullet1.Location = new System.Drawing.Point(581, 658);
            this.gamePlayerBullet1.Name = "gamePlayerBullet1";
            this.gamePlayerBullet1.Size = new System.Drawing.Size(55, 50);
            this.gamePlayerBullet1.TabIndex = 7;
            this.gamePlayerBullet1.TabStop = false;
            // 
            // gameTime
            // 
            this.gameTime.Tick += new System.EventHandler(this.gameTime_Tick);
            // 
            // gameLife1
            // 
            this.gameLife1.Location = new System.Drawing.Point(1062, 320);
            this.gameLife1.Name = "gameLife1";
            this.gameLife1.Size = new System.Drawing.Size(52, 50);
            this.gameLife1.TabIndex = 8;
            this.gameLife1.TabStop = false;
            // 
            // gamePlayerBullet2
            // 
            this.gamePlayerBullet2.Location = new System.Drawing.Point(581, 602);
            this.gamePlayerBullet2.Name = "gamePlayerBullet2";
            this.gamePlayerBullet2.Size = new System.Drawing.Size(55, 50);
            this.gamePlayerBullet2.TabIndex = 9;
            this.gamePlayerBullet2.TabStop = false;
            // 
            // gamePlayerBullet3
            // 
            this.gamePlayerBullet3.Location = new System.Drawing.Point(581, 546);
            this.gamePlayerBullet3.Name = "gamePlayerBullet3";
            this.gamePlayerBullet3.Size = new System.Drawing.Size(55, 50);
            this.gamePlayerBullet3.TabIndex = 10;
            this.gamePlayerBullet3.TabStop = false;
            // 
            // gameEnemy1
            // 
            this.gameEnemy1.Location = new System.Drawing.Point(648, 268);
            this.gameEnemy1.Name = "gameEnemy1";
            this.gameEnemy1.Size = new System.Drawing.Size(55, 50);
            this.gameEnemy1.TabIndex = 11;
            this.gameEnemy1.TabStop = false;
            // 
            // gameRemain1
            // 
            this.gameRemain1.Location = new System.Drawing.Point(1062, 483);
            this.gameRemain1.Name = "gameRemain1";
            this.gameRemain1.Size = new System.Drawing.Size(52, 50);
            this.gameRemain1.TabIndex = 12;
            this.gameRemain1.TabStop = false;
            // 
            // gameEnemy2
            // 
            this.gameEnemy2.Location = new System.Drawing.Point(821, 417);
            this.gameEnemy2.Name = "gameEnemy2";
            this.gameEnemy2.Size = new System.Drawing.Size(55, 50);
            this.gameEnemy2.TabIndex = 13;
            this.gameEnemy2.TabStop = false;
            // 
            // gameRemain2
            // 
            this.gameRemain2.Location = new System.Drawing.Point(1113, 483);
            this.gameRemain2.Name = "gameRemain2";
            this.gameRemain2.Size = new System.Drawing.Size(52, 50);
            this.gameRemain2.TabIndex = 14;
            this.gameRemain2.TabStop = false;
            // 
            // gameRemain3
            // 
            this.gameRemain3.Location = new System.Drawing.Point(1164, 483);
            this.gameRemain3.Name = "gameRemain3";
            this.gameRemain3.Size = new System.Drawing.Size(52, 50);
            this.gameRemain3.TabIndex = 15;
            this.gameRemain3.TabStop = false;
            // 
            // gameStartButton
            // 
            this.gameStartButton.Location = new System.Drawing.Point(1603, 263);
            this.gameStartButton.Name = "gameStartButton";
            this.gameStartButton.Size = new System.Drawing.Size(83, 41);
            this.gameStartButton.TabIndex = 16;
            this.gameStartButton.TabStop = false;
            this.gameStartButton.Click += new System.EventHandler(this.gameStartButton_Click);
            // 
            // PlaneShooter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1906, 1037);
            this.Controls.Add(this.gameStartButton);
            this.Controls.Add(this.gameRemain3);
            this.Controls.Add(this.gameRemain2);
            this.Controls.Add(this.gameEnemy2);
            this.Controls.Add(this.gameRemain1);
            this.Controls.Add(this.gameEnemy1);
            this.Controls.Add(this.gamePlayerBullet3);
            this.Controls.Add(this.gamePlayerBullet2);
            this.Controls.Add(this.gameLife1);
            this.Controls.Add(this.gamePlayerBullet1);
            this.Controls.Add(this.gamePlayer);
            this.Controls.Add(this.gameRemainTitle);
            this.Controls.Add(this.gameLifeTitle);
            this.Controls.Add(this.gameScreen);
            this.Controls.Add(this.gameBackground);
            this.Controls.Add(this.gameFrame);
            this.Name = "PlaneShooter";
            this.Text = "PlaneShooter";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PlaneShooter_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.gameFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameBackground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameScreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameLifeTitle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameRemainTitle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gamePlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gamePlayerBullet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameLife1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gamePlayerBullet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gamePlayerBullet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameEnemy1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameRemain1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameEnemy2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameRemain2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameRemain3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameStartButton)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox gameFrame;
        private System.Windows.Forms.PictureBox gameBackground;
        private System.Windows.Forms.PictureBox gameScreen;
        private System.Windows.Forms.PictureBox gameLifeTitle;
        private System.Windows.Forms.PictureBox gameRemainTitle;
        private System.Windows.Forms.PictureBox gamePlayer;
        private System.Windows.Forms.PictureBox gamePlayerBullet1;
        private System.Windows.Forms.Timer gameTime;
        private System.Windows.Forms.PictureBox gameLife1;
        private System.Windows.Forms.PictureBox gamePlayerBullet2;
        private System.Windows.Forms.PictureBox gamePlayerBullet3;
        private System.Windows.Forms.PictureBox gameEnemy1;
        private System.Windows.Forms.PictureBox gameRemain1;
        private System.Windows.Forms.PictureBox gameEnemy2;
        private System.Windows.Forms.PictureBox gameRemain2;
        private System.Windows.Forms.PictureBox gameRemain3;
        private System.Windows.Forms.PictureBox gameStartButton;
    }
}

