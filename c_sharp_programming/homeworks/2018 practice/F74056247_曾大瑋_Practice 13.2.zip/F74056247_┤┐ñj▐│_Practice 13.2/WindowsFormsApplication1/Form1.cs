﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        FileInfo finfo;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox3.Text!="") finfo = new FileInfo(@"" + textBox3.Text);
            if (finfo.Exists == false&&textBox3.Text!="")
            {
                FileStream fs = finfo.Create();
                fs.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            StreamWriter sw = finfo.CreateText();
            sw.Write(textBox1.Text);
            sw.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(finfo.FullName!=textBox3.Text) Directory.Move(finfo.FullName, textBox3.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            finfo = new FileInfo(@"" + textBox3.Text);
            if (finfo.Exists == true)
            {
                FileStream fs = new FileStream(@"" + textBox3.Text, FileMode.Open);
                BinaryWriter bw = new BinaryWriter(fs);
                bw.Write(textBox1.Text);
                fs.Close();
                bw.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            finfo = new FileInfo(@"" + textBox3.Text);
            if (finfo.Exists == true)
            {
                FileStream fs = new FileStream(@"" + textBox3.Text, FileMode.Open);
                BinaryReader br = new BinaryReader(fs);
                textBox2.Text = br.ReadString();
                fs.Close();
                br.Close();
            }
        }
    }
}
