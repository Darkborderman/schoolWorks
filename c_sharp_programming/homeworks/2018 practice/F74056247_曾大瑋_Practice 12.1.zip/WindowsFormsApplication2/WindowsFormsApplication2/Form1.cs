﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
            MousePressLabel.Text = "Press";
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            MousePressLabel.Text = "按了" + e.Button + "於 X:" + e.X + ", Y:" + e.Y;
        }
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            keyPressLabel.Text = "按了" + e.KeyCode + ",鍵碼:" + e.KeyValue;

            int LocationX = keyPressLabel.Location.X;
            int LocationY = keyPressLabel.Location.Y;

            if (e.KeyValue == 37) keyPressLabel.Location = new Point(LocationX - 10, LocationY);
            else if (e.KeyValue == 38) keyPressLabel.Location = new Point(LocationX, LocationY-10);
            else if (e.KeyValue == 39) keyPressLabel.Location = new Point(LocationX + 10, LocationY);
            else if (e.KeyValue == 40) keyPressLabel.Location = new Point(LocationX, LocationY+10);

        }
    }
}
