﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void inputTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float x = float.Parse(inputTextBox.Text);
                outputLabel.Text = "equal to" + x*29.12 + "NTD";
            }
            catch
            {
                MessageBox.Show("Input a vaild number!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (outputLabel.Text == "") outputLabel.Text = "Input a number";
                outputLabel.Text = "";
            }
        }
    }
}
