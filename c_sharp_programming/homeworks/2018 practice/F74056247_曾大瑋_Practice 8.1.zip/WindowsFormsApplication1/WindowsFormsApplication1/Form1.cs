﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            for (int i = 1; i <= 49; i++)
                checkedListBox1.Items.Add(i + "", false);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int counter = 0;

            for (int i = 0; i <= checkedListBox1.Items.Count - 1; i++)
            {
                if (checkedListBox1.GetItemChecked(i) == true) counter++;
            }
            int[] answer=new int[6];
            answer[0] = GetHashCode()%49;
            for (int i = 1; i <= 5; i++) answer[i] = (answer[i - 1] * 12 + 25) % 49;

            
            if (counter == 6)
            {
                counter = 0;
                for(int i=0;i<=5;i++)
                {
                    if (checkedListBox1.GetItemChecked(answer[i]) == true) counter++;
                }
                if (counter == 6)
                {
                    label1.Text = "The number is " +
                        (answer[0]+1) + " "+
                        (answer[1]+1) + " "+
                        (answer[2]+1) + " "+
                        (answer[3]+1) + " "+
                        (answer[4]+1) + " "+
                        (answer[5]+1) + " "+
                         "\n Congratulations on winning your big prize.";
                }
                else
                {

                    label1.Text = "The number is " +
                        (answer[0]+1) + " " +
                        (answer[1]+1) + " " +
                        (answer[2]+1) + " " +
                        (answer[3]+1) + " " +
                        (answer[4]+1) + " " +
                        (answer[5]+1) + " " +
                         "\n Tough luck!  Please keep it up!";
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            for(int i=0;i<=checkedListBox1.Items.Count-1;i++)
            {
                    checkedListBox1.SetItemChecked(i,false);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
