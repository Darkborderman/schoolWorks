﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.loginTab = new System.Windows.Forms.TabPage();
            this.loginButton = new System.Windows.Forms.Button();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.accountLabel = new System.Windows.Forms.Label();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.accountTextBox = new System.Windows.Forms.TextBox();
            this.englishTab = new System.Windows.Forms.TabPage();
            this.chineseTab = new System.Windows.Forms.TabPage();
            this.englishGradeLabel = new System.Windows.Forms.Label();
            this.englishTotalNumber = new System.Windows.Forms.Label();
            this.englishAverageLabel = new System.Windows.Forms.Label();
            this.chineseGradeLabel = new System.Windows.Forms.Label();
            this.chineseAverageLabel = new System.Windows.Forms.Label();
            this.chineseTotalNumber = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.loginTab.SuspendLayout();
            this.englishTab.SuspendLayout();
            this.chineseTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.loginTab);
            this.tabControl.Controls.Add(this.englishTab);
            this.tabControl.Controls.Add(this.chineseTab);
            this.tabControl.Location = new System.Drawing.Point(12, 28);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(344, 261);
            this.tabControl.TabIndex = 1;
            // 
            // loginTab
            // 
            this.loginTab.Controls.Add(this.loginButton);
            this.loginTab.Controls.Add(this.passwordLabel);
            this.loginTab.Controls.Add(this.accountLabel);
            this.loginTab.Controls.Add(this.passwordTextBox);
            this.loginTab.Controls.Add(this.accountTextBox);
            this.loginTab.Location = new System.Drawing.Point(4, 25);
            this.loginTab.Name = "loginTab";
            this.loginTab.Padding = new System.Windows.Forms.Padding(3);
            this.loginTab.Size = new System.Drawing.Size(336, 232);
            this.loginTab.TabIndex = 0;
            this.loginTab.Text = "login";
            this.loginTab.UseVisualStyleBackColor = true;
            // 
            // loginButton
            // 
            this.loginButton.Location = new System.Drawing.Point(135, 170);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(75, 23);
            this.loginButton.TabIndex = 4;
            this.loginButton.Text = "Login";
            this.loginButton.UseVisualStyleBackColor = true;
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
            // 
            // passwordLabel
            // 
            this.passwordLabel.AutoSize = true;
            this.passwordLabel.Location = new System.Drawing.Point(40, 106);
            this.passwordLabel.Name = "passwordLabel";
            this.passwordLabel.Size = new System.Drawing.Size(68, 17);
            this.passwordLabel.TabIndex = 3;
            this.passwordLabel.Text = "password";
            // 
            // accountLabel
            // 
            this.accountLabel.AutoSize = true;
            this.accountLabel.Location = new System.Drawing.Point(40, 43);
            this.accountLabel.Name = "accountLabel";
            this.accountLabel.Size = new System.Drawing.Size(58, 17);
            this.accountLabel.TabIndex = 2;
            this.accountLabel.Text = "account";
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Location = new System.Drawing.Point(114, 106);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(134, 22);
            this.passwordTextBox.TabIndex = 1;
            // 
            // accountTextBox
            // 
            this.accountTextBox.Location = new System.Drawing.Point(114, 43);
            this.accountTextBox.Name = "accountTextBox";
            this.accountTextBox.Size = new System.Drawing.Size(134, 22);
            this.accountTextBox.TabIndex = 0;
            // 
            // englishTab
            // 
            this.englishTab.Controls.Add(this.englishAverageLabel);
            this.englishTab.Controls.Add(this.englishTotalNumber);
            this.englishTab.Controls.Add(this.englishGradeLabel);
            this.englishTab.Location = new System.Drawing.Point(4, 25);
            this.englishTab.Name = "englishTab";
            this.englishTab.Padding = new System.Windows.Forms.Padding(3);
            this.englishTab.Size = new System.Drawing.Size(336, 232);
            this.englishTab.TabIndex = 1;
            this.englishTab.Text = "English";
            this.englishTab.UseVisualStyleBackColor = true;
            // 
            // chineseTab
            // 
            this.chineseTab.Controls.Add(this.chineseTotalNumber);
            this.chineseTab.Controls.Add(this.chineseAverageLabel);
            this.chineseTab.Controls.Add(this.chineseGradeLabel);
            this.chineseTab.Location = new System.Drawing.Point(4, 25);
            this.chineseTab.Name = "chineseTab";
            this.chineseTab.Padding = new System.Windows.Forms.Padding(3);
            this.chineseTab.Size = new System.Drawing.Size(336, 232);
            this.chineseTab.TabIndex = 2;
            this.chineseTab.Text = "Chinese";
            this.chineseTab.UseVisualStyleBackColor = true;
            // 
            // englishGradeLabel
            // 
            this.englishGradeLabel.AutoSize = true;
            this.englishGradeLabel.Location = new System.Drawing.Point(115, 53);
            this.englishGradeLabel.Name = "englishGradeLabel";
            this.englishGradeLabel.Size = new System.Drawing.Size(103, 17);
            this.englishGradeLabel.TabIndex = 0;
            this.englishGradeLabel.Text = "Your grade: 80";
            // 
            // englishTotalNumber
            // 
            this.englishTotalNumber.AutoSize = true;
            this.englishTotalNumber.Location = new System.Drawing.Point(115, 170);
            this.englishTotalNumber.Name = "englishTotalNumber";
            this.englishTotalNumber.Size = new System.Drawing.Size(103, 17);
            this.englishTotalNumber.TabIndex = 1;
            this.englishTotalNumber.Text = "total number: 5";
            // 
            // englishAverageLabel
            // 
            this.englishAverageLabel.AutoSize = true;
            this.englishAverageLabel.Location = new System.Drawing.Point(115, 109);
            this.englishAverageLabel.Name = "englishAverageLabel";
            this.englishAverageLabel.Size = new System.Drawing.Size(96, 17);
            this.englishAverageLabel.TabIndex = 2;
            this.englishAverageLabel.Text = "average: 86.4";
            // 
            // chineseGradeLabel
            // 
            this.chineseGradeLabel.AutoSize = true;
            this.chineseGradeLabel.Location = new System.Drawing.Point(111, 45);
            this.chineseGradeLabel.Name = "chineseGradeLabel";
            this.chineseGradeLabel.Size = new System.Drawing.Size(115, 17);
            this.chineseGradeLabel.TabIndex = 0;
            this.chineseGradeLabel.Text = "Your grade: 77.6";
            // 
            // chineseAverageLabel
            // 
            this.chineseAverageLabel.AutoSize = true;
            this.chineseAverageLabel.Location = new System.Drawing.Point(111, 106);
            this.chineseAverageLabel.Name = "chineseAverageLabel";
            this.chineseAverageLabel.Size = new System.Drawing.Size(84, 17);
            this.chineseAverageLabel.TabIndex = 1;
            this.chineseAverageLabel.Text = "average: 98";
            // 
            // chineseTotalNumber
            // 
            this.chineseTotalNumber.AutoSize = true;
            this.chineseTotalNumber.Location = new System.Drawing.Point(111, 171);
            this.chineseTotalNumber.Name = "chineseTotalNumber";
            this.chineseTotalNumber.Size = new System.Drawing.Size(103, 17);
            this.chineseTotalNumber.TabIndex = 2;
            this.chineseTotalNumber.Text = "total number: 5";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 334);
            this.Controls.Add(this.tabControl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl.ResumeLayout(false);
            this.loginTab.ResumeLayout(false);
            this.loginTab.PerformLayout();
            this.englishTab.ResumeLayout(false);
            this.englishTab.PerformLayout();
            this.chineseTab.ResumeLayout(false);
            this.chineseTab.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage loginTab;
        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Label passwordLabel;
        private System.Windows.Forms.Label accountLabel;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.TextBox accountTextBox;
        private System.Windows.Forms.TabPage englishTab;
        private System.Windows.Forms.TabPage chineseTab;
        private System.Windows.Forms.Label englishAverageLabel;
        private System.Windows.Forms.Label englishTotalNumber;
        private System.Windows.Forms.Label englishGradeLabel;
        private System.Windows.Forms.Label chineseTotalNumber;
        private System.Windows.Forms.Label chineseAverageLabel;
        private System.Windows.Forms.Label chineseGradeLabel;
    }
}

