﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input number(1>square 2>triangle)");
            int type = int.Parse(Console.ReadLine());
            if (type == 1)
            {
                Console.WriteLine("Input size");
                int size = int.Parse(Console.ReadLine());
                if (size <= 0) Console.WriteLine("Error");
                else
                {
                    for (int i = 0; i <= size - 1; i++)
                    {
                        for (int j = 0; j <= size - 1; j++)
                            Console.Write("*");

                        Console.WriteLine();
                    }
                    Console.WriteLine("Used {0} '*'", size * size);
                }
            }
            else if (type == 2)
            {
                Console.WriteLine("Input size");
                int size = int.Parse(Console.ReadLine());
                if (size <= 0) Console.WriteLine("Error");
                else
                {


                    for (int i = 1; i <= size; i++)
                    {
                        for (int j = size - 1 - i; j >= 0; j--)
                        {
                            Console.Write(" ");
                        }
                        for (int j = size + 1 - i; j <= size - 1; j++)
                        {
                            Console.Write("{0}", i);
                        }
                        Console.Write("{0}", i);
                        for (int j = size + 1 - i; j <= size - 1; j++)
                        {
                            Console.Write("{0}", i);
                        }
                        Console.WriteLine();
                    }
                    Console.Write("Used {0} sets and {1} numbers", size, size * size);
                }
            }
            else
            {
                Console.WriteLine("Error");
            }
            
            Console.Read();
        }
    }
}
