﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practice9._1
{
    public partial class Form1 : Form
    {
        public int count;
        public Form1()
        {
            InitializeComponent();
            timer1.Stop();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            if (textBox1.Text != "")
            {
                count = int.Parse(textBox1.Text);
                progressBar1.Maximum = count;
            }
            timer1.Start();
            timer1.Interval = 1000;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if(progressBar1.Value < count) progressBar1.Value ++;
            label2.Text = "" + (count - progressBar1.Value) + " Second(s) remaining.";

            if(progressBar1.Value == count)
            {
                timer1.Stop();
                label2.Text = "Finished! Time's up";
            }
        }
    }
}
