﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("請輸入盤數");
            int x = int.Parse(Console.ReadLine());
            hanoi(x, 'A', 'C', 'B');
            Console.Read();
        }
        public static void hanoi(int n, char from, char dest, char temp)
        {
            if(n >= 2) hanoi(n - 1, from, temp, dest);
            Console.WriteLine("Move sheet from {0} to {1}", from, dest);
            if (n == 1) return;
            hanoi(n - 1, temp, dest, from);
        }
    }
}
