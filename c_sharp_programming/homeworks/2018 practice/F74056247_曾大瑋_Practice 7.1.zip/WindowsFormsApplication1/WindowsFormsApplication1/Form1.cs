﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            if (minusButton.Checked == true) MyStaticValues.current = MyStaticValues.current - 1;
            else if (plusButton.Checked == true) MyStaticValues.current = MyStaticValues.current + 1;
            if (MyStaticValues.current <= 1) MyStaticValues.current = 1;
            else if (MyStaticValues.current >= 6) MyStaticValues.current = 6;
            pictureBox.Image = Image.FromFile(@"..\..\src\p" + MyStaticValues.current + ".png");
        }
    }
public static class MyStaticValues
{
        public static int current = 1;
}
}
