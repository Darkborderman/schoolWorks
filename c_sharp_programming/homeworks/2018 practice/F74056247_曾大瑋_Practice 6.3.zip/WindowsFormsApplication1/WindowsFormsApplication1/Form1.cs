﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    struct data
    {
        public
         String ID, sex, phone, address;
    }
    public partial class Form1 : Form
    {
        List<data> database=new List<data>();
        public Form1()
        {
            InitializeComponent();
            hideMainMenu();
            hideBar();
            showLogin();
        }
        public void hideMainMenu()
        {
            sexTextBox.Visible = false;
            sexLabel.Visible = false;
            addressTextBox.Visible = false;
            addressLabel.Visible = false;
            IDLabel.Visible = false;
            IDTextBox.Visible = false;
            phoneLabel.Visible = false;
            phoneTextBox.Visible = false;
            messageLabel.Visible = false;
            checkButton.Visible = false;
            saveButton.Visible = false;
            saveLabel.Visible = false;
            findButton.Visible = false;
            loginFailLabel.Visible = false;
        }
        public void hideLogin()
        {
            accountLabel.Visible = false;
            accountTextBox.Visible = false;
            passwordTextBox.Visible = false;
            passwordLabel.Visible = false;
            loginButton.Visible = false;
        }
        public void showLogin()
        {
            accountLabel.Visible = true;
            accountTextBox.Visible = true;
            passwordTextBox.Visible = true;
            passwordLabel.Visible = true;
            loginButton.Visible = true;
        }
        public void showAddMenu()
        {
            sexTextBox.Visible = true;
            sexLabel.Visible = true;
            addressTextBox.Visible = true;
            addressLabel.Visible = true;
            IDLabel.Visible = true;
            IDTextBox.Visible = true;
            phoneLabel.Visible = true;
            phoneTextBox.Visible = true;
            saveButton.Visible = true;
        }
        public void hideBar()
        {
            queryButton.Visible = false;
            logoutButton.Visible = false;
            addButton.Visible = false;
            deleteButton.Visible = false;
        }
        public void showBar()
        {
            queryButton.Visible = true;
            logoutButton.Visible = true;
            addButton.Visible = true;
            deleteButton.Visible = true;
        }
        public void showSearchMenu()
        {
            IDTextBox.Visible = true;
            IDLabel.Visible = true;
            findButton.Visible = true;
        }
        public void showDeleteMenu()
        {
            IDLabel.Visible = true;
            IDTextBox.Visible = true;
            checkButton.Visible = true;
        }
        private void loginButton_Click(object sender, EventArgs e)
        {
            if (accountTextBox.Text != "0000" || passwordTextBox.Text != "0000") loginFailLabel.Visible = true;
            else
            {
                showBar();
                hideLogin();
            }
        }

        private void logoutButton_Click(object sender, EventArgs e)
        {
            accountTextBox.Text = "";
            passwordTextBox.Text = "";
            hideMainMenu();
            showLogin();
            hideBar();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            hideMainMenu();
            showAddMenu();
        }
        private void queryButton_Click(object sender, EventArgs e)
        {
            hideMainMenu();
            showSearchMenu();
        }
        private void deleteButton_Click(object sender, EventArgs e)
        {
            hideMainMenu();
            showDeleteMenu();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            saveLabel.Visible = true;
            if (IDTextBox.Text == "" || sexTextBox.Text == "" || phoneTextBox.Text == "" || addressTextBox.Text == "")
                saveLabel.Text = "Any field can't be empty\nFill again";
            else
            {
                data temp;
                temp.ID =IDTextBox.Text;
                temp.address = sexTextBox.Text;
                temp.phone = phoneTextBox.Text;
                temp.sex = addressTextBox.Text;
                database.Add(temp);
                saveLabel.Text = "Saved,now has "+database.Count+" data";
            }
            IDTextBox.Text = "";
            sexTextBox.Text = "";
            phoneTextBox.Text = "";
            addressTextBox.Text = "";
        }
        private void findButton_Click(object sender, EventArgs e)
        {
            if (IDTextBox.Text == "")
            {
                messageLabel.Visible = true;
                messageLabel.Text = "Field can't be empty";
            }
            else
            {
                bool flag = false;
                for (int i = 0; i <= database.Count - 1; i++)
                {
                    if (IDTextBox.Text == database.ElementAt(i).ID)
                    {

                        flag = true;
                        messageLabel.Visible = false;
                        sexLabel.Visible = true;
                        sexTextBox.Visible = true;
                        sexTextBox.Text = database.ElementAt(i).sex;
                        phoneLabel.Visible = true;
                        phoneTextBox.Visible = true;
                        phoneTextBox.Text = database.ElementAt(i).phone;
                        addressLabel.Visible = true;
                        addressTextBox.Visible = true;
                        addressTextBox.Text = database.ElementAt(i).address;
                        break;
                    }
                }
                if(flag==false)
                {
                    messageLabel.Visible = true;
                    messageLabel.Text = "Not found";
                }
            }
        }
        private void checkButton_Click(object sender, EventArgs e)
        {
            bool flag = false;
            for (int i = 0; i <= database.Count - 1; i++)
            {
                if (IDTextBox.Text == database.ElementAt(i).ID)
                {
                    flag = true;
                    messageLabel.Visible = true;
                    messageLabel.Text = "Delete Success";
                    database.RemoveAt(i);
                    break;
                }
            }
            if(flag==false)
            {
                messageLabel.Visible = false;
            }
        }
    }
}
