﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace P16_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        BindingManagerBase bm;
        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                "AttachDbFilename=|DataDirectory|Hospital.mdf;" +
                "Integrated Security=True";
            DataSet ds = new DataSet();
            SqlDataAdapter daProduct = new SqlDataAdapter("SELECT * FROM doctor", cn);
            daProduct.Fill(ds, "doctor");
            nameTextbox.DataBindings.Add("Text", ds, "doctor.name");
            apartmentTextbox.DataBindings.Add("Text", ds, "doctor.所屬系別編號");
            professionTextbox.DataBindings.Add("Text", ds, "doctor.職稱");
            salaryTextbox.DataBindings.Add("Text", ds, "doctor.薪水");
            doctorIDTextbox.DataBindings.Add("Text", ds, "doctor.Did");
            bm = this.BindingContext[ds, "doctor"];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (bm.Position < bm.Count - 1) bm.Position ++;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (bm.Position >0) bm.Position--;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bm.Position = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            bm.Position = bm.Count - 1;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            Edit("INSERT INTO doctor(name,所屬系別編號,職稱,薪水,Did)VALUES('" +
                nameTextbox.Text.Replace("'", "''") + "','" +
                apartmentTextbox.Text.Replace("'", "''") + "','" +
                professionTextbox.Text.Replace("'", "''") + "'," +
                salaryTextbox.Text.Replace("'", "''") + "," +
                doctorIDTextbox.Text.Replace("'", "''") + ")");

            nameTextbox.Text = "";
            apartmentTextbox.Text = "";
            professionTextbox.Text = "";
            salaryTextbox.Text = "";
            doctorIDTextbox.Text = "";
            DataBindingsClear();
            Form1_Load(sender, e);
        }
        void DataBindingsClear()
        {
            nameTextbox.DataBindings.Clear();
            apartmentTextbox.DataBindings.Clear();
            professionTextbox.DataBindings.Clear();
            salaryTextbox.DataBindings.Clear();
            doctorIDTextbox.DataBindings.Clear();
        }
        void Edit(string sqlstr)
        {
            try
            {
                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                    "AttachDbFilename=|DataDirectory|Hospital.mdf;" +
                    "Integrated Security=True";
                cn.Open();
                SqlCommand cmd = new SqlCommand(sqlstr, cn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
