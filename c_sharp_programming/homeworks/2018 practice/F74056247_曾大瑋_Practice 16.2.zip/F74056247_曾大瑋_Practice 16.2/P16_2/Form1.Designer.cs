﻿namespace P16_2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.nameTextbox = new System.Windows.Forms.TextBox();
            this.nextButton = new System.Windows.Forms.Button();
            this.previousButton = new System.Windows.Forms.Button();
            this.apartmentTextbox = new System.Windows.Forms.TextBox();
            this.apartmentIDLabel = new System.Windows.Forms.Label();
            this.firstButton = new System.Windows.Forms.Button();
            this.professionTextbox = new System.Windows.Forms.TextBox();
            this.professionLabel = new System.Windows.Forms.Label();
            this.lastButton = new System.Windows.Forms.Button();
            this.salaryTextbox = new System.Windows.Forms.TextBox();
            this.salaryLabel = new System.Windows.Forms.Label();
            this.addButton = new System.Windows.Forms.Button();
            this.doctorIDTextbox = new System.Windows.Forms.TextBox();
            this.doctorIDLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(23, 21);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(45, 17);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name";
            // 
            // nameTextbox
            // 
            this.nameTextbox.Location = new System.Drawing.Point(124, 21);
            this.nameTextbox.Name = "nameTextbox";
            this.nameTextbox.Size = new System.Drawing.Size(100, 22);
            this.nameTextbox.TabIndex = 1;
            // 
            // nextButton
            // 
            this.nextButton.Location = new System.Drawing.Point(251, 17);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(75, 25);
            this.nextButton.TabIndex = 2;
            this.nextButton.Text = "Next";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // previousButton
            // 
            this.previousButton.Location = new System.Drawing.Point(251, 57);
            this.previousButton.Name = "previousButton";
            this.previousButton.Size = new System.Drawing.Size(75, 25);
            this.previousButton.TabIndex = 5;
            this.previousButton.Text = "Previous";
            this.previousButton.UseVisualStyleBackColor = true;
            this.previousButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // apartmentTextbox
            // 
            this.apartmentTextbox.Location = new System.Drawing.Point(124, 57);
            this.apartmentTextbox.Name = "apartmentTextbox";
            this.apartmentTextbox.Size = new System.Drawing.Size(100, 22);
            this.apartmentTextbox.TabIndex = 4;
            // 
            // apartmentIDLabel
            // 
            this.apartmentIDLabel.AutoSize = true;
            this.apartmentIDLabel.Location = new System.Drawing.Point(23, 57);
            this.apartmentIDLabel.Name = "apartmentIDLabel";
            this.apartmentIDLabel.Size = new System.Drawing.Size(90, 17);
            this.apartmentIDLabel.TabIndex = 3;
            this.apartmentIDLabel.Text = "Apartment ID";
            // 
            // firstButton
            // 
            this.firstButton.Location = new System.Drawing.Point(251, 103);
            this.firstButton.Name = "firstButton";
            this.firstButton.Size = new System.Drawing.Size(75, 25);
            this.firstButton.TabIndex = 8;
            this.firstButton.Text = "First";
            this.firstButton.UseVisualStyleBackColor = true;
            this.firstButton.Click += new System.EventHandler(this.button3_Click);
            // 
            // professionTextbox
            // 
            this.professionTextbox.Location = new System.Drawing.Point(124, 103);
            this.professionTextbox.Name = "professionTextbox";
            this.professionTextbox.Size = new System.Drawing.Size(100, 22);
            this.professionTextbox.TabIndex = 7;
            // 
            // professionLabel
            // 
            this.professionLabel.AutoSize = true;
            this.professionLabel.Location = new System.Drawing.Point(23, 103);
            this.professionLabel.Name = "professionLabel";
            this.professionLabel.Size = new System.Drawing.Size(75, 17);
            this.professionLabel.TabIndex = 6;
            this.professionLabel.Text = "Profession";
            // 
            // lastButton
            // 
            this.lastButton.Location = new System.Drawing.Point(251, 148);
            this.lastButton.Name = "lastButton";
            this.lastButton.Size = new System.Drawing.Size(75, 25);
            this.lastButton.TabIndex = 11;
            this.lastButton.Text = "Last";
            this.lastButton.UseVisualStyleBackColor = true;
            this.lastButton.Click += new System.EventHandler(this.button4_Click);
            // 
            // salaryTextbox
            // 
            this.salaryTextbox.Location = new System.Drawing.Point(124, 149);
            this.salaryTextbox.Name = "salaryTextbox";
            this.salaryTextbox.Size = new System.Drawing.Size(100, 22);
            this.salaryTextbox.TabIndex = 10;
            // 
            // salaryLabel
            // 
            this.salaryLabel.AutoSize = true;
            this.salaryLabel.Location = new System.Drawing.Point(23, 154);
            this.salaryLabel.Name = "salaryLabel";
            this.salaryLabel.Size = new System.Drawing.Size(48, 17);
            this.salaryLabel.TabIndex = 9;
            this.salaryLabel.Text = "Salary";
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(251, 195);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 25);
            this.addButton.TabIndex = 14;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.button5_Click);
            // 
            // doctorIDTextbox
            // 
            this.doctorIDTextbox.Location = new System.Drawing.Point(124, 196);
            this.doctorIDTextbox.Name = "doctorIDTextbox";
            this.doctorIDTextbox.Size = new System.Drawing.Size(100, 22);
            this.doctorIDTextbox.TabIndex = 13;
            // 
            // doctorIDLabel
            // 
            this.doctorIDLabel.AutoSize = true;
            this.doctorIDLabel.Location = new System.Drawing.Point(23, 196);
            this.doctorIDLabel.Name = "doctorIDLabel";
            this.doctorIDLabel.Size = new System.Drawing.Size(67, 17);
            this.doctorIDLabel.TabIndex = 12;
            this.doctorIDLabel.Text = "Doctor ID";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 235);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.doctorIDTextbox);
            this.Controls.Add(this.doctorIDLabel);
            this.Controls.Add(this.lastButton);
            this.Controls.Add(this.salaryTextbox);
            this.Controls.Add(this.salaryLabel);
            this.Controls.Add(this.firstButton);
            this.Controls.Add(this.professionTextbox);
            this.Controls.Add(this.professionLabel);
            this.Controls.Add(this.previousButton);
            this.Controls.Add(this.apartmentTextbox);
            this.Controls.Add(this.apartmentIDLabel);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.nameTextbox);
            this.Controls.Add(this.nameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox nameTextbox;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.Button previousButton;
        private System.Windows.Forms.TextBox apartmentTextbox;
        private System.Windows.Forms.Label apartmentIDLabel;
        private System.Windows.Forms.Button firstButton;
        private System.Windows.Forms.TextBox professionTextbox;
        private System.Windows.Forms.Label professionLabel;
        private System.Windows.Forms.Button lastButton;
        private System.Windows.Forms.TextBox salaryTextbox;
        private System.Windows.Forms.Label salaryLabel;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.TextBox doctorIDTextbox;
        private System.Windows.Forms.Label doctorIDLabel;
    }
}

