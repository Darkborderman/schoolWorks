﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            timer1.Interval = 100;
            timer1.Start();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
                Form1.text = Form1.text + "\n" + textBox1.Text;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = Form1.text;
        }
    }
}
