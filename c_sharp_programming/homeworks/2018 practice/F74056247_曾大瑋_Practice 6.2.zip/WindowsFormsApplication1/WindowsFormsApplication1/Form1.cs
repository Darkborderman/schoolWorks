﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.BackColor = Color.LightPink;
            label1.ForeColor = Color.Yellow;
            label1.Text = "C# class practice";
            label2.Text = "Style change";
            textBox1.Text = "Trytest";
            label2.Font = new Font("標楷體", 30, FontStyle.Bold);
            button3.TextAlign =ContentAlignment.TopLeft;
            textBox1.TextAlign = HorizontalAlignment.Right;
            pictureBox1.BackColor = Color.Black;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.BackColor = Color.BlueViolet;
            label1.ForeColor = Color.YellowGreen;
            label1.Text = "C# class practice";
            label2.Text = "Style change";
            textBox1.Text = "Trytest";
            label2.Font = new Font("細明體", 30, FontStyle.Strikeout);
            button3.TextAlign = ContentAlignment.BottomRight;
            textBox1.TextAlign = HorizontalAlignment.Left;
            pictureBox1.BackColor = Color.Silver;
        }
    }
}
