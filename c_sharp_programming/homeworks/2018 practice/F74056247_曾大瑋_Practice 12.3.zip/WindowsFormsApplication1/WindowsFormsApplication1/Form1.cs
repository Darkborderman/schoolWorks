﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Button[] btn = new Button[9];
        int count = 0;
        bool win = false;
        String phase = "X";
        private void Form1_Load(object sender, EventArgs e)
        {
            btn[0] = button1; btn[1] = button2; btn[2] = button3;
            btn[3] = button4; btn[4] = button5; btn[5] = button6;
            btn[6] = button7; btn[7] = button8; btn[8] = button9;
            button2.Click += button1_Click; button3.Click += button1_Click;
            button4.Click += button1_Click; button5.Click += button1_Click;
            button6.Click += button1_Click; button7.Click += button1_Click;
            button8.Click += button1_Click; button9.Click += button1_Click;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button btnClick = (Button)sender;
            if(btnClick.Text=="")
            {
                btnClick.Text = phase;
                count++;
                if (phase == "X") phase = "O";
                else phase = "X";
            }
            for(int i=0;i<=2;i++)
            {
                if (btn[0 + i].Text == btn[3 + i].Text && btn[0 + i].Text == btn[6 + i].Text && btn[0 + i].Text != ""&&win==false)
                {
                    win = true;
                    MessageBox.Show(btn[0 + i].Text+ " wins!","OK");
                }
                if (btn[0 +3* i].Text == btn[1 +3* i].Text && btn[0 +3* i].Text == btn[2 +3* i].Text && btn[0 +3* i].Text != "" && win == false)
                {
                    win = true;
                    MessageBox.Show(btn[0 + i].Text + " wins!", "OK");
                }
            }
            if (btn[0].Text == btn[4].Text && btn[0].Text == btn[8].Text && btn[0].Text != "" && win == false)
            {
                win = true;
                MessageBox.Show(btn[0].Text+" wins!","OK");
            }
            if (btn[2].Text == btn[4].Text && btn[2].Text == btn[6].Text && btn[2].Text != "" && win == false)
            {
                win = true;
                MessageBox.Show(btn[2].Text);
            }

            if (count==9)
                MessageBox.Show("duce","OK");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            win = false;
            for (int i = 0; i <= 8; i++) btn[i].Text = "";
        }
    }
}
