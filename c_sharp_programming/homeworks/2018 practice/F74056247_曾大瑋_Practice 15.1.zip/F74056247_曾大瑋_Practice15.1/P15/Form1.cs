﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
namespace P15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection db = new SqlConnection();
            db.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                "AttachDbFilename=|DataDirectory|Hospital.mdf;" +
                "Integrated Security=True";
             string cn = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                "AttachDbFilename=|DataDirectory|Hospital.mdf;" +
                "Integrated Security=True";
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM 系科別", db);
            DataSet ds = new DataSet();
            SqlDataAdapter daPublisher = new SqlDataAdapter("SELECT * FROM 系科別", cn);
            daPublisher.Fill(ds, "系科別");
            SqlDataAdapter daBook = new SqlDataAdapter("SELECT * FROM doctor", cn);
            daBook.Fill(ds, "doctor");
            
            ds.Relations.Add("系科別", ds.Tables["系科別"].Columns["Pid"],ds.Tables["doctor"].Columns["所屬系別編號"]);
            dataGridView1.Dock = DockStyle.Top;     
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "系科別";
            dataGridView2.Dock = DockStyle.Fill;    
            dataGridView2.DataSource = ds;
            dataGridView2.DataMember = "系科別.系科別";
        }
    }
}
