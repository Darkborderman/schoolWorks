﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("請輸入十進位數字");
            int input=int.Parse(Console.ReadLine());
            Console.WriteLine("向左或向右移動<左為1右為2>");
            int shift=int.Parse(Console.ReadLine());
            Console.WriteLine("移動幾位<以2進位的狀態下移動>");
            int digit = int.Parse(Console.ReadLine());
            Console.WriteLine("==================================");
            Console.WriteLine("您所輸入的值為{0}",input);
            int output;
            if(shift-1 == 0)
            {
                output=input<<digit;
                Console.WriteLine("您所輸入的值向左移動{0}位後,結果為{1}",digit,output);
            }
            else
            {
                output=input>>digit;
                Console.WriteLine("您所輸入的值向右移動{0}位後,結果為{1}", digit, output);
            }
            Console.Read();
            
        }
    }
}
